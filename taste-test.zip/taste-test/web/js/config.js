// Paste the web app URL from Apps Script (Deploy → Manage deployments) here.
window.TT_CONFIG = {
  API_URL: 'PASTE_YOUR_WEB_APP_URL_HERE'
};
